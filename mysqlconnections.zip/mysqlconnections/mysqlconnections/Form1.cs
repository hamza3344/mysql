﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace mysqlconnections
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            string query="insert into mydatabase.mytable(name,number) values ('"+textBox1.Text+"','" + textBox2.Text + "')";
            MySqlCommand mycom = new MySqlCommand(query, conn);
            conn.Open();
            mycom.ExecuteReader();
            conn.Close();
            MessageBox.Show("save data");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            string query = "update mydatabase.mytable set name='" + textBox1.Text + "',number=" + textBox2.Text + " where id='1'";
            MySqlCommand com = new MySqlCommand(query, conn);
            conn.Open();
            com.ExecuteReader();
            conn.Close();
            MessageBox.Show("sve data");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            string query="delete from mydatabase.mytable where name='"+textBox1.Text+"'";
            MySqlCommand comm = new MySqlCommand(query, conn);
            conn.Open();
            comm.ExecuteReader();
            conn.Close();
            MessageBox.Show("delete");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            string query = "select * from mydatabase.mytable;";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter myadt = new MySqlDataAdapter();
            myadt.SelectCommand = comm;
            DataTable dt = new DataTable();
            myadt.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
